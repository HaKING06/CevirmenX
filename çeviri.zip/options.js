document.addEventListener('DOMContentLoaded', sozluguYukle);

document.getElementById('ekleBtn').addEventListener('click', () => {
  let kelime = document.getElementById('kelime').value.toLowerCase().trim();
  let cevirisi = document.getElementById('cevirisi').value.trim();

  if (!kelime || !cevirisi) return;

  chrome.storage.sync.get(['ozelSozluk'], (result) => {
    let sozluk = result.ozelSozluk || {};
    sozluk[kelime] = cevirisi; // Yeni kelimeyi sözlüğe ekle

    chrome.storage.sync.set({ ozelSozluk: sozluk }, () => {
      document.getElementById('kelime').value = "";
      document.getElementById('cevirisi').value = "";
      sozluguYukle(); // Listeyi güncelle
    });
  });
});

function sozluguYukle() {
  chrome.storage.sync.get(['ozelSozluk'], (result) => {
    let sozluk = result.ozelSozluk || {};
    let listeDiv = document.getElementById('sozlukListesi');
    listeDiv.innerHTML = "";

    if (Object.keys(sozluk).length === 0) {
      listeDiv.innerHTML = "<p style='color:#777; text-align:center;'>Sözlüğünüz şu an boş. Yukarıdan yeni kelimeler ekleyebilirsiniz.</p>";
      return;
    }

    for (let [kelime, cevirisi] of Object.entries(sozluk)) {
      let div = document.createElement('div');
      div.className = 'list-item';
      div.innerHTML = `
        <span><strong>${kelime}</strong> ➔ ${cevirisi}</span>
        <button class="delete-btn" data-kelime="${kelime}">Sil</button>
      `;
      listeDiv.appendChild(div);
    }

    document.querySelectorAll('.delete-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        let silinecek = e.target.getAttribute('data-kelime');
        sozluktenSil(silinecek);
      });
    });
  });
}

function sozluktenSil(kelime) {
  chrome.storage.sync.get(['ozelSozluk'], (result) => {
    let sozluk = result.ozelSozluk || {};
    delete sozluk[kelime];
    chrome.storage.sync.set({ ozelSozluk: sozluk }, () => sozluguYukle());
  });
}