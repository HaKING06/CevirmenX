document.addEventListener('DOMContentLoaded', () => {
  chrome.storage.sync.get(['hedefDil'], (result) => {
    if (result.hedefDil) {
      document.getElementById("dilSecimi").value = result.hedefDil;
    }
  });
});

// Dil Kaydetme Butonu
document.getElementById("kaydetBtn").addEventListener("click", () => {
  let secilenDil = document.getElementById("dilSecimi").value;
  
  chrome.storage.sync.set({ hedefDil: secilenDil }, () => {
    let btn = document.getElementById("kaydetBtn");
    btn.innerText = "Kaydedildi! ✓";
    btn.style.backgroundColor = "#28a745"; 
    
    setTimeout(() => {
      window.close();
    }, 1000);
  });
});

// Ayarlar (Sözlük) Sayfasını Açma Butonu
document.getElementById("ayarlarBtn").addEventListener("click", () => {
  if (chrome.runtime.openOptionsPage) {
    chrome.runtime.openOptionsPage(); // Chrome'un modern API'si ile aç
  } else {
    window.open(chrome.runtime.getURL('options.html')); // Eski sürümler için yedek plan
  }
});