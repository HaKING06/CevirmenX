chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "cevir_sag_tik",
    title: "Çevir ve Değiştir",
    contexts: ["selection", "editable"]
  });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === "cevir_sag_tik") {
    chrome.tabs.sendMessage(tab.id, { action: "cevir" }).catch(e => console.log("Hata:", e));
  }
});

chrome.commands.onCommand.addListener((command) => {
  if (command === "cevir_kisayol") {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0]) chrome.tabs.sendMessage(tabs[0].id, { action: "cevir" }).catch(e => console.log("Hata:", e));
    });
  }
});