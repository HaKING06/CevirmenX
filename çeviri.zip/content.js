// --- ŞIK BİLDİRİM (TOAST) OLUŞTURUCU ---
function toastGoster(mesaj, tip = "bilgi") {
  let toast = document.createElement("div");
  toast.innerText = mesaj;
  toast.style.cssText = `
    position: fixed; bottom: 20px; right: 20px; padding: 12px 24px;
    border-radius: 8px; color: white; font-family: Arial, sans-serif;
    font-size: 14px; font-weight: bold; z-index: 999999;
    box-shadow: 0 4px 12px rgba(0,0,0,0.15); transition: opacity 0.3s ease;
  `;
  
  if (tip === "hata") toast.style.backgroundColor = "#dc3545";
  else if (tip === "basari") toast.style.backgroundColor = "#28a745";
  else toast.style.backgroundColor = "#1a73e8";

  document.body.appendChild(toast);
  
  setTimeout(() => {
    toast.style.opacity = "0";
    setTimeout(() => toast.remove(), 300);
  }, 2000);
}

// --- METİN DEĞİŞTİRME FONKSİYONU ---
function metniDegistir(aktifElement, yeniKelime) {
  let baslangic = aktifElement.selectionStart;
  let bitis = aktifElement.selectionEnd;
  let yeniMetin = aktifElement.value.substring(0, baslangic) + yeniKelime + aktifElement.value.substring(bitis);

  aktifElement.value = yeniMetin;
  aktifElement.selectionStart = baslangic;
  aktifElement.selectionEnd = baslangic + yeniKelime.length;
}

// --- ANA DİNLEYİCİ ---
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "cevir") {
    let aktifElement = document.activeElement;

    if (aktifElement && (aktifElement.tagName === 'TEXTAREA' || aktifElement.tagName === 'INPUT')) {
      let seciliMetin = aktifElement.value.substring(aktifElement.selectionStart, aktifElement.selectionEnd);

      if (seciliMetin.length > 0) {
        let temizMetin = seciliMetin.toLowerCase().trim();
        let orijinalMetin = seciliMetin;

        // BURADA HEM DİLİ HEM DE KULLANICININ ÖZEL SÖZLÜĞÜNÜ HAFIZADAN ÇEKİYORUZ
        chrome.storage.sync.get(['hedefDil', 'ozelSozluk'], (result) => {
          let secilenDil = result.hedefDil || 'en'; 
          let dinamikSozluk = result.ozelSozluk || {}; 

          if (secilenDil === 'en' && dinamikSozluk[temizMetin]) {
            metniDegistir(aktifElement, dinamikSozluk[temizMetin]);
            toastGoster("Sözlükten Çevrildi ✓", "basari");
          } else {
            metniDegistir(aktifElement, "⏳ Çevriliyor...");

            let apiUrl = `https://api.mymemory.translated.net/get?q=${encodeURIComponent(orijinalMetin)}&langpair=tr|${secilenDil}`;

            fetch(apiUrl)
              .then(response => response.json())
              .then(data => {
                let cevrilenMetin = data.responseData.translatedText;
                metniDegistir(aktifElement, cevrilenMetin);
                toastGoster("Çeviri Başarılı ✓", "basari");
              })
              .catch(error => {
                console.error('Çeviri hatası:', error);
                metniDegistir(aktifElement, orijinalMetin);
                toastGoster("Hata: Çeviri Yapılamadı!", "hata");
              });
          }
        });
      }
    }
  }
});